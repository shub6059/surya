<?php

define( 'REDIRECTION_VERSION', '5.2.3' );
define( 'REDIRECTION_BUILD', 'cb109e7c800603ff2d5cc098451320be' );
define( 'REDIRECTION_MIN_WP', '4.6' );
